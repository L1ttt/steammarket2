# Crp1t0_Market
COS30049-Computing Technology Innovation Project
1. Clone the Repository:
git clone https://github.com/DuySeu/Steam_Market.git

2. Install NodeJS:
Download nodeJS: https://nodejs.org/en (recomment version)

3. Install Git:
Download Git: https://gitforwindows.org/

Lấy code về:
git pull

Đẩy code lên:
git add .
git commit -m "sua Readme"
git push

# For Backend
4. Regularly Update:
To stay updated with the project, regularly pull the latest changes: git pull

Additional Notes:
Ensure that your XAMPP environment is properly configured, especially the PHP and MySQL settings.

Refer to the project documentation for any specific configurations or database setup instructions.
